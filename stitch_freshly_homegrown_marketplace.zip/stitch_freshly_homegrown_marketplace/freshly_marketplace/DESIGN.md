---
name: Freshly Marketplace
colors:
  surface: '#fbf9f8'
  surface-dim: '#dbd9d9'
  surface-bright: '#fbf9f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f3f3'
  surface-container: '#efeded'
  surface-container-high: '#eae8e7'
  surface-container-highest: '#e4e2e2'
  on-surface: '#1b1c1c'
  on-surface-variant: '#424844'
  inverse-surface: '#303030'
  inverse-on-surface: '#f2f0f0'
  outline: '#727973'
  outline-variant: '#c2c8c2'
  surface-tint: '#496455'
  primary: '#173124'
  on-primary: '#ffffff'
  primary-container: '#2d4739'
  on-primary-container: '#98b5a3'
  inverse-primary: '#b0cdbb'
  secondary: '#675d4d'
  on-secondary: '#ffffff'
  secondary-container: '#f0e0cc'
  on-secondary-container: '#6e6353'
  tertiary: '#2b2c2a'
  on-tertiary: '#ffffff'
  tertiary-container: '#414240'
  on-tertiary-container: '#aeaeac'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ccead6'
  primary-fixed-dim: '#b0cdbb'
  on-primary-fixed: '#062014'
  on-primary-fixed-variant: '#324c3e'
  secondary-fixed: '#f0e0cc'
  secondary-fixed-dim: '#d3c4b1'
  on-secondary-fixed: '#221a0e'
  on-secondary-fixed-variant: '#4f4537'
  tertiary-fixed: '#e3e2e0'
  tertiary-fixed-dim: '#c7c6c4'
  on-tertiary-fixed: '#1a1c1a'
  on-tertiary-fixed-variant: '#464745'
  background: '#fbf9f8'
  on-background: '#1b1c1c'
  surface-variant: '#e4e2e2'
typography:
  h1:
    fontFamily: Newsreader
    fontSize: 48px
    fontWeight: '600'
    lineHeight: '1.2'
  h2:
    fontFamily: Newsreader
    fontSize: 32px
    fontWeight: '500'
    lineHeight: '1.3'
  h3:
    fontFamily: Newsreader
    fontSize: 24px
    fontWeight: '500'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '700'
    lineHeight: '1.2'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 12px
  md: 24px
  lg: 48px
  xl: 80px
  container-max: 1280px
  gutter: 24px
---

## Brand & Style

The brand personality is rooted in the "farm-to-table" ethos: transparent, grounded, and premium yet accessible. The target audience includes health-conscious consumers and local artisans who value quality and sustainability. 

This design system utilizes a **Minimalist-Tactile** style. It blends the clean efficiency of modern digital interfaces with the warmth of physical, organic textures. The visual response should feel like a high-end boutique grocery store—calm, organized, and deeply trustworthy. High use of whitespace ensures that product photography remains the focal point, while the "Warm Sand" tones prevent the interface from feeling sterile or overly corporate.

## Colors

The palette is intentionally limited to evoke a sense of natural simplicity. 

*   **Deep Forest Green (Primary):** Used for branding, primary actions, and success states. It represents growth and reliability.
*   **Warm Sand (Background/Accents):** Used for global backgrounds and subtle section dividers to provide a soft, non-glare reading environment.
*   **Soft White (Surfaces):** Used specifically for cards, modals, and input fields to make them "pop" against the sand background without creating harsh contrast.
*   **Deep Earth (Text):** A very dark grey-brown, used instead of pure black to maintain the organic warmth across all typography.

## Typography

This design system employs a sophisticated typographic pairing to balance tradition and modernity. 

**Newsreader** is utilized for all headings. Its editorial, serif qualities lend an air of authority and "homegrown" authenticity. It should be used with generous leading to maintain a relaxed, organic rhythm.

**Plus Jakarta Sans** is the workhorse for body text, UI labels, and navigation. Its soft, rounded terminals echo the organic theme while ensuring high legibility on mobile devices and desktops. Use the "Medium" weight for interactive elements to ensure they feel sturdy and clickable.

## Layout & Spacing

The design system follows a **Fixed Grid** model for desktop and a fluid model for mobile. On large screens, content is contained within a 1280px centered container to maintain focus. 

The spacing rhythm is built on an 8px baseline. To achieve the "Minimalist" aesthetic, use the `lg` (48px) and `xl` (80px) tokens frequently to separate major sections. This abundance of whitespace conveys a premium feel and prevents the marketplace from feeling cluttered. Gutters between product cards should be kept at a consistent 24px to allow the "Soft White" surfaces room to breathe against the "Warm Sand" background.

## Elevation & Depth

Hierarchy is established through **Ambient Shadows** and **Tonal Layering**. 

1.  **Background:** The "Warm Sand" color acts as the lowest layer.
2.  **Surface:** "Soft White" surfaces sit on top. 
3.  **Elevation:** For interactive cards and buttons, use a very soft, diffused shadow. The shadow should not use pure black; instead, use a semi-transparent version of "Deep Forest Green" (e.g., #2D4739 at 8% opacity) with a large blur radius (16px to 24px) and a slight vertical offset (4px).

This creates a "natural light" effect, as if the UI elements are physical objects resting on a sunlit surface. Avoid harsh borders; let the subtle color shift and soft shadows define the boundaries.

## Shapes

The shape language is defined by **Rounded** geometry. Sharp corners are avoided to maintain the "approachable" and "organic" brand promise.

*   **Primary Containers:** Product cards and image containers use the `rounded-lg` (1rem) setting.
*   **Buttons & Inputs:** Use the base `rounded` (0.5rem) setting.
*   **Search Bars & Badges:** These use the `rounded-xl` (1.5rem) or full pill-shape to distinguish them from functional containers.

The consistency of these rounded corners creates a friendly, safe visual environment that reinforces the "trustworthy" pillar of the brand.

## Components

### Buttons
Primary buttons are solid "Deep Forest Green" with "Soft White" text. Secondary buttons use a "Deep Forest Green" border with no fill. Always use the `label-md` type style, centered, with 16px vertical padding.

### Verified Badges
A signature component for the marketplace. These should be small, pill-shaped chips with a "Soft White" background and "Deep Forest Green" text and icon (a simple leaf or checkmark). They should have a subtle 1px border of the primary color to ensure visibility.

### Quantity Steppers
Steppers should be tactile. Use a horizontal layout: a minus button, the quantity value in `body-md`, and a plus button. These buttons should have a "Soft White" fill and a subtle shadow to make them appear "pressable."

### Cards
Product cards are the core of the experience. Use a "Soft White" background, `rounded-lg` corners, and the ambient shadow defined in the Elevation section. Images should have a subtle 0.5s zoom-in transition on hover to lean into the "Freshly" theme.

### Input Fields
Inputs should use the "Soft White" surface color with a 1px "Secondary" color border. Upon focus, the border transitions to the "Primary" color. Place labels above the field using `label-sm` in all caps for a clean, organized look.